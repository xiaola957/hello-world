//#include <iostream>
#include <stdbool.h>
//#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "stack.h"
#include <malloc.h>

SDL_Renderer *SdlRender = NULL;

SDL_Surface *C_sur;
SDL_Texture *TexC;

SDL_Rect tubeRect[10];

/*void Jug(stack *p[],SDL_Rect tubeRect[]){	
	for(int i = 0 ; i < 1 ; i++){		
		for(int j = 0 ; j < p[i]->top ; j++){
			switch(p[i]->data[j]){
				case 'r':
			}
			SDL_Rect CRect = tubeRect[i+1];
			
			str[0] = p[i]->data[j];	
			SDL_Surface *C_sur = IMG_Load(str);
			SDL_Texture *TexC = SDL_CreateTextureFromSurface(SdlRender, C_sur);		
			SDL_RenderCopy(SdlRender, TexC, NULL, &CRect);
		}		
	}
}*/





void C_render(stack *p[],SDL_Rect tubeRect[]){	
	char* str = malloc(7*sizeof(char));
	str[2] = '.';
	str[3] = 'p';
	str[4] = 'n';
	str[5] = 'g';
	str[6] = '\0';
	int i,j;
	for(i = 0 ; i < 9 ; i++){		
		for(j = 0 ; j < p[i]->top ; j++){
			SDL_Rect CRect = tubeRect[i + 1];
			if(j == 0){
				str[1] = '2';
			}else{
				str[1] = '3';
				CRect.y -= 38*(j-1);
			}
			str[0] = p[i]->data[j];	
			C_sur = IMG_Load(str);
			TexC = SDL_CreateTextureFromSurface(SdlRender, C_sur);		
			SDL_RenderCopy(SdlRender, TexC, NULL, &CRect);
		}		
	}
}


int main(int args, char *argv[])
{
	// 初始化SDL
	if (SDL_Init(SDL_INIT_EVERYTHING) == -1) { return -1; }

	// 初始化SDL_image
	if (IMG_Init(IMG_INIT_PNG) == 0) { return -1; }

	// 加载png,得到表面
	//背景
	SDL_Surface *BackGround = IMG_Load("BK3.png");
	if (!BackGround) { return -1; }

	//滴管
	SDL_Surface *ImgSurface = IMG_Load("di5.png");
	if (!ImgSurface) { return -1; }
	SDL_Surface *di2 = IMG_Load("di6.png");
	if (!di2) { return -1; }

	//试管
	SDL_Surface *tube1 = IMG_Load("Little_shi.png");
	if (!tube1) { return -1; }

	//色块
	/*SDL_Surface *cubeg1 = IMG_Load("g1.png");
	if (!cubeg1) { return -1; }
	SDL_Surface *cubeg2 = IMG_Load("g2.png");
	if (!cubeg2) { return -1; }
	SDL_Surface *cubep1 = IMG_Load("p1.png");
	if (!cubep1) { return -1; }
	SDL_Surface *cubep2 = IMG_Load("p2.png");
	if (!cubep2) { return -1; }*/

	//


	stack *p[9];
    for(int i = 0 ; i < 9 ; i++ ){
        p[i]=StackCreate();            //创建栈 	
    }
    Roll(p);
	
	






	
	/*SDL_Surface *tube2 = IMG_Load("Little_shi.png");
	if (!tube2) { return -1; }
	SDL_Surface *tube3 = IMG_Load("Little_shi.png");
	if (!tube3) { return -1; }
	SDL_Surface *tube4 = IMG_Load("Little_shi.png");
	if (!tube4) { return -1; }
	SDL_Surface *tube5 = IMG_Load("Little_shi.png");
	if (!tube5) { return -1; }
	SDL_Surface *tube6 = IMG_Load("Little_shi.png");
	if (!tube6) { return -1; }
	SDL_Surface *tube7 = IMG_Load("Little_shi.png");
	if (!tube4) { return -1; }
	SDL_Surface *tube8 = IMG_Load("Little_shi.png");
	if (!tube5) { return -1; }
	SDL_Surface *tube9 = IMG_Load("Little_shi.png");
	if (!tube6) { return -1; }*/

	// 创建窗口
	SDL_Window *SdlWindow = SDL_CreateWindow("main", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,  900/*ImgSurface->w*/, 800/*ImgSurface->h*/, SDL_WINDOW_SHOWN);
	if (!SdlWindow) { return -1; }

	// 创建渲染器
	SdlRender = SDL_CreateRenderer(SdlWindow, -1, SDL_RENDERER_ACCELERATED);
	if (!SdlRender) { return -1; }

	// 创建纹理
	//背景
	SDL_Texture *SdlTextureBK = SDL_CreateTextureFromSurface(SdlRender, BackGround);
	if (!SdlTextureBK) { return -1; }

	//滴管
	SDL_Texture *SdlTexture = SDL_CreateTextureFromSurface(SdlRender, ImgSurface);
	if (!SdlTexture) { return -1; }

	//试管
	SDL_Texture *Sdltube1 = SDL_CreateTextureFromSurface(SdlRender, tube1);
	if (!Sdltube1) { return -1; }

	//色块
	/*SDL_Texture *Sdlcubeg1 = SDL_CreateTextureFromSurface(SdlRender, cubeg1);
	if (!Sdlcubeg1) { return -1; }
	SDL_Texture *Sdlcubeg2 = SDL_CreateTextureFromSurface(SdlRender, cubeg2);
	if (!Sdlcubeg2) { return -1; }
	SDL_Texture *Sdlcubep1 = SDL_CreateTextureFromSurface(SdlRender, cubep1);
	if (!Sdlcubep1) { return -1; }
	SDL_Texture *Sdlcubep2 = SDL_CreateTextureFromSurface(SdlRender, cubep2);
	if (!Sdlcubep2) { return -1; }*/

	/*SDL_Texture *Sdltube2 = SDL_CreateTextureFromSurface(SdlRender, tube2);
	if (!Sdltube2) { return -1; }
	SDL_Texture *Sdltube3 = SDL_CreateTextureFromSurface(SdlRender, tube3);
	if (!Sdltube3) { return -1; }
	SDL_Texture *Sdltube4 = SDL_CreateTextureFromSurface(SdlRender, tube4);
	if (!Sdltube4) { return -1; }
	SDL_Texture *Sdltube5 = SDL_CreateTextureFromSurface(SdlRender, tube5);
	if (!Sdltube5) { return -1; }
	SDL_Texture *Sdltube6 = SDL_CreateTextureFromSurface(SdlRender, tube6);
	if (!Sdltube6) { return -1; }
	SDL_Texture *Sdltube7 = SDL_CreateTextureFromSurface(SdlRender, tube7);
	if (!Sdltube7) { return -1; }
	SDL_Texture *Sdltube8 = SDL_CreateTextureFromSurface(SdlRender, tube8);
	if (!Sdltube8) { return -1; }
	SDL_Texture *Sdltube9 = SDL_CreateTextureFromSurface(SdlRender, tube9);
	if (!Sdltube9) { return -1; }*/

	// 创建图片位置、尺寸
	//背景
	SDL_Rect BKRect;
	BKRect.w = BackGround->w;
	BKRect.h = BackGround->h;
	BKRect.x = 0/*(ImgSurface->w - dstRect.w) / 2*/;
	BKRect.y = 0/*(ImgSurface->h - dstRect.h) / 2*/;

	//滴管							 	//100*150
	
	SDL_Rect dstRect;
	dstRect.w = ImgSurface->w;
	dstRect.h = ImgSurface->h;
	dstRect.x = 750/*(ImgSurface->w - dstRect.w) / 2*/;
	dstRect.y = 600/*(ImgSurface->h - dstRect.h) / 2*/;

	//试管                              //150*225
	tubeRect[1].w = tube1->w;
	tubeRect[1].h = tube1->h;
	tubeRect[1].x = 20/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[1].y = 50/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[2].w = tube1->w;
	tubeRect[2].h = tube1->h;
	tubeRect[2].x = 200/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[2].y = 50/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[3].w = tube1->w;
	tubeRect[3].h = tube1->h;
	tubeRect[3].x = 380/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[3].y = 50/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[4].w = tube1->w;
	tubeRect[4].h = tube1->h;
	tubeRect[4].x = 20/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[4].y = 300/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[5].w = tube1->w;
	tubeRect[5].h = tube1->h;
	tubeRect[5].x = 200/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[5].y = 300/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[6].w = tube1->w;
	tubeRect[6].h = tube1->h;
	tubeRect[6].x = 380/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[6].y = 300/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[7].w = tube1->w;
	tubeRect[7].h = tube1->h;
	tubeRect[7].x = 20/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[7].y = 550/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[8].w = tube1->w;
	tubeRect[8].h = tube1->h;
	tubeRect[8].x = 200/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[8].y = 550/*(tube1->h - dstRect2.h) / 2*/;

	tubeRect[9].w = tube1->w;
	tubeRect[9].h = tube1->h;
	tubeRect[9].x = 380/*(tube1->w - dstRect2.w) / 2*/;
	tubeRect[9].y = 550/*(tube1->h - dstRect2.h) / 2*/;

	


	


	SDL_Point leftPPoint;
	SDL_Event SdlEvent;
	bool quit = true;
	while (quit)
	{
		while (SDL_PollEvent(&SdlEvent))
		{
			switch (SdlEvent.type)
			{
				// 退出
			case SDL_QUIT:quit = false; break;

				// 键盘
			case SDL_KEYDOWN:
				if (SdlEvent.key.keysym.sym == SDLK_ESCAPE) { quit = false; break; }
				if (SdlEvent.key.keysym.sym == SDLK_UP)		{ dstRect.y -= 10; }
				if (SdlEvent.key.keysym.sym == SDLK_DOWN)	{ dstRect.y += 10; }
				if (SdlEvent.key.keysym.sym == SDLK_LEFT)	{ dstRect.x	-= 10; }
				if (SdlEvent.key.keysym.sym == SDLK_RIGHT)	{ dstRect.x	+= 10; }
				if (SdlEvent.key.keysym.sym == SDLK_SPACE) 
				{
					dstRect.w = 400;
					dstRect.h = 300;
					dstRect.x = (ImgSurface->w - dstRect.w) / 2;
					dstRect.y = (ImgSurface->h - dstRect.h) / 2;
				}
				break;

				// 鼠标按键
			case SDL_MOUSEBUTTONDOWN:
				if (SdlEvent.button.button == SDL_BUTTON_LMASK)
				{
					leftPPoint.x = SdlEvent.button.x;
					leftPPoint.y = SdlEvent.button.y;
				}
				break;
			case SDL_MOUSEMOTION:
				if (SdlEvent.button.button == SDL_BUTTON_LMASK)
				{
					SDL_Point tLeftPPoint;
					tLeftPPoint.x = SdlEvent.button.x;
					tLeftPPoint.y = SdlEvent.button.y;

					dstRect.x += tLeftPPoint.x - leftPPoint.x;
					dstRect.y += tLeftPPoint.y - leftPPoint.y;

					leftPPoint = tLeftPPoint;
				}
				break;

			case SDL_MOUSEBUTTONUP:
				dstRect.x = 750;
				dstRect.y = 600;
				SDL_Point upPoint;
				upPoint.x = SdlEvent.button.x;
				upPoint.y = SdlEvent.button.y;
				if(upPoint.x >= 20 && upPoint.x <= 170 && upPoint.y >= 50 && upPoint.y <= 275){
					
					SdlTexture = SDL_CreateTextureFromSurface(SdlRender, di2);
					if (!di2) { return -1; }
				}
				if(upPoint.x >= 200 && upPoint.x <= 350 && upPoint.y >= 50 && upPoint.y <= 275){
					
				}
				if(upPoint.x >= 380 && upPoint.x <= 530 && upPoint.y >= 50 && upPoint.y <= 275){
					
				}
				if(upPoint.x >= 20 && upPoint.x <= 170 && upPoint.y >= 300 && upPoint.y <= 525){
					
				}
				if(upPoint.x >= 200 && upPoint.x <= 350 && upPoint.y >= 300 && upPoint.y <= 525){
					
				}
				if(upPoint.x >= 380 && upPoint.x <= 530 && upPoint.y >= 300 && upPoint.y <= 525){
					
				}
				if(upPoint.x >= 20 && upPoint.x <= 170 && upPoint.y >= 550 && upPoint.y <= 775){
					
				}
				if(upPoint.x >= 200 && upPoint.x <= 350 && upPoint.y >= 550 && upPoint.y <= 775){
					
				}
				if(upPoint.x >= 380 && upPoint.x <= 530 && upPoint.y >= 550 && upPoint.y <= 775){
					
				}
				

				// 鼠标滚轮
			/*case SDL_MOUSEWHEEL:
				if (SdlEvent.wheel.y > 0)
				{
					dstRect.w *= 1.1;
					dstRect.h *= 1.1;
					//dstRect.x = (ImgSurface->w - dstRect.w) / 2;
					//dstRect.y = (ImgSurface->h - dstRect.h) / 2;
				}
				if (SdlEvent.wheel.y < 0)
				{
					dstRect.w /= 1.1;
					dstRect.h /= 1.1;
					//dstRect.x = (ImgSurface->w - dstRect.w) / 2;
					//dstRect.y = (ImgSurface->h - dstRect.h) / 2;
				}
				break;*/
			}
		}

		

		if (SDL_RenderClear(SdlRender) != 0) { return -1; }
		//背景
		if (SDL_RenderCopy(SdlRender, SdlTextureBK, NULL, &BKRect) != 0) { return -1; }

		//试管
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[1]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[2]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[3]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[4]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[5]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[6]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[7]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[8]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdltube1, NULL, &tubeRect[9]) != 0) { return -1; }
		
		/*SDL_Rect Crect;
		Crect = tubeRect[1];
		Crect.y -= 38;*/
		//色块
		/*if (SDL_RenderCopy(SdlRender, Sdlcubeg1, NULL, &tubeRect[1]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdlcubeg2, NULL, &tubeRect[1]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdlcubep1, NULL, &tubeRect[2]) != 0) { return -1; }
		if (SDL_RenderCopy(SdlRender, Sdlcubep2, NULL, &Crect) != 0) { return -1; }*/

		C_render(p,tubeRect);

		//滴管
		if (SDL_RenderCopy(SdlRender, SdlTexture, NULL, &dstRect) != 0) { return -1; }

			

		SDL_RenderPresent(SdlRender);

		//SDL_Delay(20);
		SDL_FreeSurface(C_sur);
	}

	SDL_DestroyTexture(SdlTexture);			// 销毁纹理
	SDL_DestroyRenderer(SdlRender);			// 销毁渲染器
	SDL_DestroyWindow(SdlWindow);			// 销毁窗口

	SDL_FreeSurface(ImgSurface);			// 销毁表面

	SDL_FreeSurface(tube1);			        // 销毁表面

	SDL_FreeSurface(C_sur);
	/*SDL_FreeSurface(cubeg1);			        // 销毁表面
	SDL_FreeSurface(cubeg2);			        // 销毁表面
	SDL_FreeSurface(cubep1);			        // 销毁表面
	SDL_FreeSurface(cubep2);			        // 销毁表面*/

	SDL_FreeSurface(BackGround);			// 销毁表面

	IMG_Quit();								// 退出SDL_image
	SDL_Quit();								// 退出SDL

	//std::cout << std::endl << "---------- end ----------" << std::endl;
	return 0;
}
