#include "stack.h"


//创建试管，并给每个试管放入一种颜色（后续打乱）
stack *StackCreate(){
	stack *p=(stack*)malloc(sizeof(stack));//分配新空间 
	if(p==NULL)//分配失败 
	    return 0;
	p->bottom=p->top=0;//分配成功 
	return p;
}




//入栈
void StackInput(stack *p,char str)
{
    if(isFull(p))
    {
        p->data[p->top] = str;    //存入栈中 
	    p->top++;                 //栈顶指针加1 
    }   
} 



//出栈
char StackOutput(stack *p)
{
    char str;
	if(isEmpty(p))                 //判断栈非空 
    {                
		str = p->data[p->top-1];    //栈顶内容输出 
		p->top--;                   //栈顶减1 
		return str;                 //返回出栈元素
	}
} 



//判断栈是否为空
bool isEmpty(stack *p)
{
    // 如果下标在0，说明栈中无元素
    if(p->top != 0)
    {
        return true;   //非空
    }
    return false;      //空 
}



// 判断栈是否已满
bool isFull(stack *p)
{
    // 已满返回true(1)
    if(p->top != MaxSize)  //栈顶指针指到栈中所含元素总数时为满
    {
        return true;       //非满
    }
    return false;          //满 
}


//实现倒水功能
/*void PullWater(stack *p1,stack *p2)     //试管p1向试管p2倒水
{
    char x;
    if(!isEmpty(p1)){                   //判断试管p1是否是空的

    }
    else if(!isFull(p2)){               //判断试管p2是否是满的

    }
    do{
        x = StackOutput(p1);
        StackInput(p2,x);     //将试管p1与顶部颜色相同的色块全部出栈，入栈到p2中
    }while(x == p1 -> data[p1 -> top - 1]);
    
}*/



//判断一个试管中颜色是否全部相同,或者为空
bool same(stack *p)
{
    bool flag = true;
    for( int i = 0 ; i < MaxSize - 1 ; i++ ){
        if(!isEmpty(p)){
            flag = false;
            break;
        }
        if(isFull(p)){
            flag = false;
            break;
        }
        if(p->data[i] != p->data[i+1]){
            flag = false;
        } 
    }
    return flag;
}



//判断游戏是否成功
bool Success(stack *p[])
{
    bool flag = true;
    for(int i = 0 ; i < 9 ; i++){
        if(!same(p[i]))
            flag = false;
    }
    return flag;
}



//实现该游戏有解的算法
void Roll(stack *p[])                 
{
    for(int i = 0 ; i < 7 ; i++){
        switch(i)
        {
        case 0: StackInput(p[i],'r');StackInput(p[i],'r');StackInput(p[i],'r');StackInput(p[i],'r');break;
        case 1: StackInput(p[i],'s');StackInput(p[i],'s');StackInput(p[i],'s');StackInput(p[i],'s');break;
        case 2: StackInput(p[i],'g');StackInput(p[i],'g');StackInput(p[i],'g');StackInput(p[i],'g');break;
        case 3: StackInput(p[i],'p');StackInput(p[i],'p');StackInput(p[i],'p');StackInput(p[i],'p');break;
        case 4: StackInput(p[i],'y');StackInput(p[i],'y');StackInput(p[i],'y');StackInput(p[i],'y');break;
        case 5: StackInput(p[i],'o');StackInput(p[i],'o');StackInput(p[i],'o');StackInput(p[i],'o');break;
        case 6: StackInput(p[i],'b');StackInput(p[i],'b');StackInput(p[i],'b');StackInput(p[i],'b');break;
        }
    }
    
    int r = rand() % 51 + 50;  
    int n = 0;
    int m,t,km = 0,kt = 0;          //km和kt用于防止两个试管相互倒水
    do{
        m = rand() % tubeNumber;
        t = rand() % tubeNumber;
        if(m == t)
            continue;
        if(km == t && kt == m)
        {
            continue;
        }
        if(isEmpty(p[m]) && isFull(p[t]))
        {
            StackInput(p[t],StackOutput(p[m]));     
        }
        else
        {
            continue;
        }
        km = m;
        kt = t;
        n++;
    }while(n <= r);
}

