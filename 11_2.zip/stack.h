#ifndef STACK_H
#define STACK_H

/*
颜色：
r--------red    红色
s--------sky    天蓝色
g--------green  绿色
p--------purple 紫色
y--------yellow 黄色
o--------orange 橙色
b--------brown  棕色
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
//#include<string.h>
#include <stdbool.h>
#include "stack.h"

#define tubeNumber 9;   //试管数量
#define colorNumber 7;  //颜色数量
//const int MaxSize = 4 ;     //栈中所含元素总数
#define MaxSize 4

//栈结构
typedef struct
{
 

    char data[MaxSize];     //栈内元素
	int top;                //栈顶
	int bottom;             //栈底
}stack;

stack *StackCreate();
void StackInput(stack *p,char str);
char StackOutput(stack *p);
bool isEmpty(stack *p);
bool isFull(stack *p);
//void PullWater(stack *p1,stack *p2);
bool same(stack *p);
bool Success(stack *p[]);
void Roll(stack *p[]) ;






#endif