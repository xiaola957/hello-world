#ifndef TUBE_H
#define TUBE_H

/*
颜色：
r--------red    红色
s--------sky    天蓝色
g--------green  绿色
p--------purple 紫色
y--------yellow 黄色
o--------orange 橙色
b--------brown  棕色
*/

#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
//#include<string.h>
#include <stdbool.h>


const int tubeNumber = 9;   //试管数量
const int colorNumber = 7;  //颜色数量
//const int MaxSize = 4 ;     //栈中所含元素总数
#define MaxSize 4

//栈结构
typedef struct
{
 

    char data[MaxSize];     //栈内元素
	int top;                //栈顶
	int bottom;             //栈底
}stack;

void StackInput(stack *p,char str);
char StackOutput(stack *p);
bool isEmpty(stack *p);
bool isFull(stack *p);
//void PullWater(stack *p1,stack *p2);
bool same(stack *p);
bool Success(stack *p[]);
void Roll(stack *p[]) ;





//创建试管，并给每个试管放入一种颜色（后续打乱）
void StackCreate(stack *p,int n)
{
	//stack *p = (stack*)malloc(sizeof(stack));     //分配新空间 
	/*if( p == NULL ){                            //分配失败 

    }                             
    else{
        p->bottom = p->top = 0;                 //分配成功 
    }*/

    p->bottom = p->top = 0;

    switch(n)
    {
        case 1: StackInput(p,'r');StackInput(p,'r');StackInput(p,'r');StackInput(p,'r');p->top = MaxSize;break;
        case 2: StackInput(p,'s');StackInput(p,'s');StackInput(p,'s');StackInput(p,'s');p->top = MaxSize;break;
        case 3: StackInput(p,'g');StackInput(p,'g');StackInput(p,'g');StackInput(p,'g');p->top = MaxSize;break;
        case 4: StackInput(p,'p');StackInput(p,'p');StackInput(p,'p');StackInput(p,'p');p->top = MaxSize;break;
        case 5: StackInput(p,'y');StackInput(p,'y');StackInput(p,'y');StackInput(p,'y');p->top = MaxSize;break;
        case 6: StackInput(p,'o');StackInput(p,'o');StackInput(p,'o');StackInput(p,'o');p->top = MaxSize;break;
        case 7: StackInput(p,'b');StackInput(p,'b');StackInput(p,'b');StackInput(p,'b');p->top = MaxSize;break;
    }   
}



//入栈
void StackInput(stack *p,char str)
{
    if(!isFull(p))
    {
        p->data[p->top] = str;    //存入栈中 
	    p->top++;                 //栈顶指针加1 
    }   
} 



//出栈
char StackOutput(stack *p)
{
    char str;
	if(!isEmpty(p))                 //判断栈非空 
    {                
		str = p->data[p->top-1];    //栈顶内容输出 
		p->top--;                   //栈顶减1 
		return str;                 //返回出栈元素
	}
} 



//判断栈是否为空
bool isEmpty(stack *p)
{
    // 如果下标在0，说明栈中无元素
    if(p->top != 0)
    {
        return true;   //非空
    }
    return false;      //空 
}



// 判断栈是否已满
bool isFull(stack *p)
{
    // 已满返回true(1)
    if(p->top != MaxSize)  //栈顶指针指到栈中所含元素总数时为满
    {
        return true;       //非满
    }
    return false;          //满 
}


//实现倒水功能
/*void PullWater(stack *p1,stack *p2)     //试管p1向试管p2倒水
{
    char x;
    if(!isEmpty(p1)){                   //判断试管p1是否是空的

    }
    else if(!isFull(p2)){               //判断试管p2是否是满的

    }
    do{
        x = StackOutput(p1);
        StackInput(p2,x);     //将试管p1与顶部颜色相同的色块全部出栈，入栈到p2中
    }while(x == p1 -> data[p1 -> top - 1]);
    
}*/



//判断一个试管中颜色是否全部相同,或者为空
bool same(stack *p)
{
    bool flag = true;
    for( int i = 0 ; i < MaxSize - 1 ; i++ ){
        if(!isEmpty(p)){
            flag = false;
            break;
        }
        if(isFull(p)){
            flag = false;
            break;
        }
        if(p->data[i] != p->data[i+1]){
            flag = false;
        } 
    }
    return flag;
}



//判断游戏是否成功
bool Success(stack *p[])
{
    bool flag = true;
    for(int i = 0 ; i < tubeNumber ; i++){
        if(!same(p[i]))
            flag = false;
    }
    return flag;
}



//实现该游戏有解的算法
void Roll(stack *p[])                 
{
    int r = rand() % 51 + 50;  
    int n = 0;
    int m,t,km = 0,kt = 0;          //km和kt用于防止两个试管相互倒水
    do{
        m = rand() % tubeNumber;
        t = rand() % tubeNumber;
        if(m == t)
            continue;
        if(km == t && kt == m)
        {
            continue;
        }
        if(!isEmpty(p[m]) && !isFull(p[n]))
        {
            StackInput(p[t],StackOutput(p[m]));     
        }
        else
        {
            continue;
        }
        km = m;
        kt = t;
        n++;
    }while(n <= r);
}






#endif